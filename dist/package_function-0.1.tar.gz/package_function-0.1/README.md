#mypackage
This library was created and will perform the task of returning array of items, sorted in ascending order.

##building this package locally
'python set.py sdist'https://github.com/neomopedi/package_function.git

##installing this package from Github
'pip install git'https://github.com/neomopedi/package_function.git

##updating this package from Github
'pip install -- upgrade  git'https://github.com/neomopedi/package_function.git
"# package_function" 
# package_function
